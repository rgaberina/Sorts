import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

/**
 * 
 */

/**
 * @author berina
 *
 */
public class FastCollinearPoints {

	private ArrayList<LineSegment> lines;

	/** finds all line segments containing 4 or more points */
	public FastCollinearPoints(Point[] points) {
		checkPoints(points);
		//		Arrays.sort(points);
		lines = new ArrayList<>();
		Point[] tempPoints = copyPointArray(points);
		ArrayList<Double> slopes = new ArrayList<>();
		ArrayList<String> linePoints = new ArrayList<>();
		for (int i = 0; i < points.length; i++) {
			Arrays.sort(tempPoints, points[i].slopeOrder());
			for (int j = 0; j < tempPoints.length-2; j++) {
				double slope1 = points[i].slopeTo(tempPoints[j]);
				double slope2 = points[i].slopeTo(tempPoints[j+1]);
				double slope3 = points[i].slopeTo(tempPoints[j+2]);
				if (slope1 == slope2 && slope2 == slope3) {
					Point[] temp = new Point[4];
					temp[0] = points[i];
					temp[1] = tempPoints[j];
					temp[2] = tempPoints[j+1];
					temp[3] = tempPoints[j+2];
					Arrays.sort(temp);
					//					String lineP = temp[0] + "," + temp[1] + "," + temp[2] + "," + temp[3];
					String lineP = temp[0] + "," + temp[3];
					LineSegment line = new LineSegment(temp[0], temp[3]);
					if(!linePoints.contains(lineP)) {
						if (!slopes.contains(slope1)) {
							lines.add(line);
							slopes.add(slope1);
							linePoints.add(lineP);
						} 
					}
				}
			}
		}
	}

		private void checkPoints(Point[] points) {
			if (points == null)
				throw new IllegalArgumentException();
			for (int i = 0; i < points.length; i++) {
				if (points[i] == null)
					throw new IllegalArgumentException();
				for (int j = i+1; j < points.length; j++) {
					if (points[j] == null)
						throw new IllegalArgumentException();
					if (points[i].compareTo(points[j]) == 0)
						throw new IllegalArgumentException();
				}
			}
		}

		private Point[] copyPointArray(Point[] points) {
			Point[] newPoints = new Point[points.length];
			for (int i = 0; i < points.length; i++)
				newPoints[i] = points[i];
			return newPoints;
		}

		/** the number of line segments */
		public int numberOfSegments() {
			return lines.size();
		}

		/** the line segments */
		public LineSegment[] segments() {
			LineSegment[] temp = new LineSegment[lines.size()];
			return lines.toArray(temp);
		}

		public static void main(String[] args) {
			// read the n points from a file
			In in = new In(args[0]);
			int n = in.readInt();
			Point[] points = new Point[n];
			for (int i = 0; i < n; i++) {
				int x = in.readInt();
				int y = in.readInt();
				points[i] = new Point(x, y);
			}

			// draw the points
			StdDraw.enableDoubleBuffering();
			StdDraw.setXscale(0, 32768);
			StdDraw.setYscale(0, 32768);
			for (Point p : points) {
				p.draw();
			}
			StdDraw.show();

			// print and draw the line segments
			FastCollinearPoints collinear = new FastCollinearPoints(points);
			for (LineSegment segment : collinear.segments()) {
				StdOut.println(segment);
				segment.draw();
			}
			StdDraw.show();
		}
	}
